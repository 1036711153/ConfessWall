package com.confress.lovewall.biz.IListener;

/**
 * Created by admin on 2016/3/15.
 */
public interface OnSuggestionListener {
    void OnSusscess();
    void OnFailed();
}
