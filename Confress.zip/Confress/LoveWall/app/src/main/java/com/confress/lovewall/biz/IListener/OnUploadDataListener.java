package com.confress.lovewall.biz.IListener;

/**
 * Created by admin on 2016/3/11.
 */
public interface OnUploadDataListener {
    void OnSusscess();
    void OnFailed();
}
