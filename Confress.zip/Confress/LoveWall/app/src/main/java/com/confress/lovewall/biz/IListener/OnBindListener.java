package com.confress.lovewall.biz.IListener;

/**
 * Created by admin on 2016/3/16.
 */
public interface OnBindListener {
    void OnSuccess();

    void OnFailed();
}
