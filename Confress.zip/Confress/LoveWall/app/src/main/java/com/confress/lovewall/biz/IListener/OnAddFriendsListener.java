package com.confress.lovewall.biz.IListener;

/**
 * Created by admin on 2016/3/16.
 */
public interface OnAddFriendsListener {
    void OnSuccess();

    void OnFailed();
}
