package com.confress.lovewall.biz.IListener;

/**
 * Created by admin on 2016/3/7.
 */
public interface OnRememberPsdListener {
    void OnSusscess();
    void OnFailed();
}
