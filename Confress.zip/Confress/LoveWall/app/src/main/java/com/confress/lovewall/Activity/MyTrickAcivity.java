package com.confress.lovewall.Activity;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by admin on 2016/3/14.
 */
public class MyTrickAcivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
