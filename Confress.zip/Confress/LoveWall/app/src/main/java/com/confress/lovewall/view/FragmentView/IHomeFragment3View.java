package com.confress.lovewall.view.FragmentView;

import com.confress.lovewall.model.User;

/**
 * Created by admin on 2016/3/13.
 */
public interface IHomeFragment3View {
    void Failure();
    User getCurrentUser();
}
