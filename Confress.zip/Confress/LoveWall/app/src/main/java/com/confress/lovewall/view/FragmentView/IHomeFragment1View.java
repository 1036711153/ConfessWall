package com.confress.lovewall.view.FragmentView;

import android.support.v4.app.Fragment;

/**
 * Created by admin on 2016/3/7.
 */
public interface IHomeFragment1View {
    Fragment toNewsFragmnet();
    Fragment toHotFragmnet();
    Fragment toAnonmousFragmnet();

}
